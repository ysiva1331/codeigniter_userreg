<?php
class PersonModel extends CI_Model {
	
	private $tbl_person= 'users';
	
	function Person(){
		parent::Model();
	}
	
	function list_all(){
		$this->db->order_by('id','asc');
		return $this->db->get($tbl_person);
	}
	
	function count_all(){
		return $this->db->count_all($this->tbl_person);
	}
	
	function get_paged_list($limit = 10, $offset = 0){
		$this->db->order_by('id','asc');
		return $this->db->get($this->tbl_person, $limit, $offset);
	}
	
	function get_by_id($id){
		$this->db->where('id', $id);
		return $this->db->get($this->tbl_person);
	}
	
	function save($person){
		$this->db->insert($this->tbl_person, $person);
		return $this->db->insert_id();
	}
	
	function update($id, $person){
		$this->db->where('id', $id);
		$this->db->update($this->tbl_person, $person);
	}
	
	function delete($id){
		$this->db->where('id', $id);
		$this->db->delete($this->tbl_person);
	}
	function auth($email_address,$password){
	//echo $email_address;
	//exit;
        $password = sha1($password);
        $this->db->where('email_address',$email_address);
        $this->db->where('password',$password);
         $query = $this->db->get('users');
		//exit;
        if($query->num_rows()==1){
		//echo "test1331";
		//exit;
            foreach ($query->result() as $row){
                $data = array(
                            'full_name'=> $row->full_name,
                            'logged_in'=>TRUE
                        );
            }
            $this->session->set_userdata($data);
            return TRUE;
        }
        else{
            return FALSE;
      }
        
    }
    
}
?>