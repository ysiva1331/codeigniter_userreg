<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>User Login</title>

<link href="<?php echo base_url(); ?>style/style.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<div class="content">
		<h1><?php echo $title; ?></h1>
		<?php echo $message; ?>
		<form method="post" action="<?php echo $action; ?>">
		<div class="data">
		<table>				
			<tr>
				<td valign="top">Email Address<span style="color:red;">*</span></td>
				<td><input type="text" name="email_address" class="text" value="<?php echo $this->validation->email_address; ?>"/>
				<?php echo $this->validation->email_address_error; ?></td>
			</tr>
			<tr>
				<td valign="top">Password<span style="color:red;">*</span></td>
				<td><input type="password" name="password" class="text" value="<?php echo $this->validation->password; ?>"/>
				<?php echo $this->validation->password_error; ?></td>
			</tr>
			
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" value="Login"/></td>
			</tr>
		</table>
		</div>
		</form>
		<br />
		<?php echo $link_back; ?>
	</div>
</body>
</html>