<?php
class Person extends CI_Controller{

	// num of records per page
	private $limit = 10;
	
	function Person(){
		//parent::Controller();
		 parent::__construct();
		
		// load library
		$this->load->library(array('table','validation'));
		$this->load->library('session');
		// load helper
		$this->load->helper('url');
		
		
		// load model
		$this->load->model('personModel','',TRUE);
	}
	
	public function is_logged_in(){
        
        header("cache-Control: no-store, no-cache, must-revalidate");
        header("cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
        $is_logged_in = $this->session->userdata('logged_in');
        
        if(!isset($is_logged_in) || $is_logged_in!==TRUE)
        {
            redirect('person/login/');
        }
    }
	
	function index($offset = 0){
	 $this->is_logged_in();
		// offset
		$uri_segment = 3;
		$offset = $this->uri->segment($uri_segment);
		
		// load data
		$persons = $this->personModel->get_paged_list($this->limit, $offset)->result();
		
		// generate pagination
		$this->load->library('pagination');
		$config['base_url'] = site_url('person/index/');
 		$config['total_rows'] = $this->personModel->count_all();
 		$config['per_page'] = $this->limit;
		$config['uri_segment'] = $uri_segment;
		$this->pagination->initialize($config);
		$data['pagination'] = $this->pagination->create_links();
		
		// generate table data
		$this->load->library('table');
		$this->table->set_empty("&nbsp;");
		$this->table->set_heading('No', 'Full Name','Email Address', 'Gender', 'About Me', 'Actions');
		$i = 0 + $offset;
		foreach ($persons as $person){
			$this->table->add_row(++$i, $person->full_name, $person->email_address, strtoupper($person->gender)=='M'? 'Male':'Female', $person->about_me, 
				anchor('person/view/'.$person->id,'view',array('class'=>'view')).' '.
				anchor('person/update/'.$person->id,'update',array('class'=>'update')).' '.
				anchor('person/delete/'.$person->id,'delete',array('class'=>'delete','onclick'=>"return confirm('Are you sure want to delete this person?')"))
			);
		}
		$data['table'] = $this->table->generate();
		
		// load view
		$this->load->view('personList', $data);
		$data['logout'] = anchor('person/logout/','Logout',array('class'=>'back'));
		}
	//login
	function login(){
	// set validation properties
		$this->_set_fields();		
		// set common properties
		$data['title'] = 'User Login';
		$data['message'] = '';
		$data['action'] = site_url('person/auth');
		$data['link_back'] = anchor('person/index/','Back to list of persons',array('class'=>'back'));
	
		// load view
		$this->load->view('personLogin', $data);
	}
	//log the user out
	function logout()
	{
		$this->data['title'] = "Logout";

		$this->session->unset_userdata(array("full_name"=>"","logged_in"=>"","password"=>"","email_address"=>""));
$this->session->sess_destroy();
		redirect('person/login', 'refresh');
	}
	function auth(){
	
	//echo $this->input->post('email_address');
	$this->personModel->auth($this->input->post('email_address'),$this->input->post('password'));	
	// redirect to person list page
	redirect('person/index/','refresh');
	}
	
	function add(){
	 $this->is_logged_in();
		// set validation properties
		$this->_set_fields();
		
		// set common properties
		$data['title'] = 'Add new person';
		$data['message'] = '';
		$data['action'] = site_url('person/addPerson');
		$data['link_back'] = anchor('person/index/','Back to list of persons',array('class'=>'back'));
	
		// load view
		$this->load->view('personEdit', $data);
	}
	
	function addPerson(){
	
		// set common properties
		$data['title'] = 'Add new person';
		$data['action'] = site_url('person/addPerson');
		$data['link_back'] = anchor('person/index/','Back to list of persons',array('class'=>'back'));
		
		// set validation properties
		$this->_set_fields();
		$this->_set_rules();
		
		// run validation
		if ($this->validation->run() == FALSE){
			$data['message'] = '';
		}else{
			// save data
			$person = array('full_name' => $this->input->post('full_name'),
			'email_address' => $this->input->post('email_address'),
			'password' => sha1($this->input->post('password')),
							'gender' => $this->input->post('gender'),
							'about_me' => $this->input->post('about_me'));
			$id = $this->personModel->save($person);
			
			// set form input name="id"
			$this->validation->id = $id;
			
			// set user message
			$data['message'] = '<div class="success">add new person success</div>';
		}
		
		// load view
		$this->load->view('personEdit', $data);
	}
	
	function view($id){
	 $this->is_logged_in();
		// set common properties
		$data['title'] = 'Person Details';
		$data['link_back'] = anchor('person/index/','Back to list of persons',array('class'=>'back'));
		
		// get person details
		$data['person'] = $this->personModel->get_by_id($id)->row();
		
		// load view
		$this->load->view('personView', $data);
	}
	
	function update($id){
	 $this->is_logged_in();
		// set validation properties
		$this->_set_fields();
		
		// prefill form values
		$person = $this->personModel->get_by_id($id)->row();
		$this->validation->id = $id;
		$this->validation->full_name = $person->full_name;
		$this->validation->email_address = $person->email_address;
		$this->validation->about_me = $person->about_me;
		$_POST['gender'] = strtoupper($person->gender);
		//$this->validation->dob = date('d-m-Y',strtotime($person->dob));
		
		// set common properties
		$data['title'] = 'Update person';
		$data['message'] = '';
		$data['action'] = site_url('person/updatePerson');
		$data['link_back'] = anchor('person/index/','Back to list of persons',array('class'=>'back'));
	
		// load view
		$this->load->view('personEdit', $data);
	}
	
	function updatePerson(){
	 $this->is_logged_in();
		// set common properties
		$data['title'] = 'Update person';
		$data['action'] = site_url('person/updatePerson');
		$data['link_back'] = anchor('person/index/','Back to list of persons',array('class'=>'back'));
		
		// set validation properties
		$this->_set_fields();
		$this->_set_rules();
		
		// run validation
		if ($this->validation->run() == FALSE){
			$data['message'] = '';
		}else{
			// save data
			$id = $this->input->post('id');
			$person = array('full_name' => $this->input->post('full_name'),
			'email_address' => $this->input->post('email_address'),
							'gender' => $this->input->post('gender'),
							'about_me' => $this->input->post('about_me')
							);
			$this->personModel->update($id,$person);
			
			// set user message
			$data['message'] = '<div class="success">update person success</div>';
		}
		
		// load view
		$this->load->view('personEdit', $data);
	}
	
	function delete($id){
	 $this->is_logged_in();
		// delete person
		$this->personModel->delete($id);
		
		// redirect to person list page
		redirect('person/index/','refresh');
	}
	
	// validation fields
	function _set_fields(){
		$fields['id'] = 'id';
		$fields['full_name'] = 'full_name';
		$fields['email_address'] = 'email_address';
		$fields['password'] = 'password';
		$fields['gender'] = 'gender';
		$fields['about_me'] = 'about_me';
		$this->validation->set_fields($fields);
	}
	
	// validation rules
	function _set_rules(){
		$rules['full_name'] = 'trim|required';
		$rules['email_address'] = 'trim|required';
		$rules['password'] = 'trim|required';
		$rules['gender'] = 'trim|required';
		$rules['about_me'] = 'trim|required';		
		//$rules['dob'] = 'trim|required|callback_valid_date';
		
		$this->validation->set_rules($rules);
		
		$this->validation->set_message('required', '* required');
		$this->validation->set_message('isset', '* required');
		$this->validation->set_error_delimiters('<p class="error">', '</p>');
	}
	
	// date_validation callback
	function valid_date($str)
	{
		if(!preg_match("/^(0[1-9]|1[0-9]|2[0-9]|3[01])-(0[1-9]|1[012])-([0-9]{4})$/", $str))
		{
			$this->validation->set_message('valid_date', 'date format is not valid. dd-mm-yyyy');
			return false;
		}
		else
		{
			return true;
		}
	}
}
?>